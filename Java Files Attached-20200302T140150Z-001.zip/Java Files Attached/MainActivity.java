package com.androidcodefinder.FacultyAssigner;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.androidcodefinder.FacultyAssigner.User;
import com.androidcodefinder.FacultyAssigner.DatabaseHelper;
import com.androidcodefinder.loginapp.SignUp;
import com.androidcodefinder.loginapp.choose_subjects;

import java.util.*;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper dbh = new DatabaseHelper(this);
    UserChoiceDbHelper dbh_ = new UserChoiceDbHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        User akshay = new User(1, "Akshay Jain", "akkI7", "a");
//
//       dbh.addUser(akshay);

//        dbh.deleteUser(akshay);

        Button logIn = findViewById(R.id.login);


        logIn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText username_ = findViewById(R.id.username);
                EditText password_ = findViewById(R.id.password);

                if(username_.getText().toString().equals("admin") &&
                        password_.getText().toString().equals("123")){
                    startActivity(new Intent(getApplicationContext(),admin.class));
                }

                String promptTo;

                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(password_.getWindowToken(), 0);

                } catch (Exception e) {
                    // TODO: handle exception
                }

                User verfied = dbh.checkUser(username_.getText().toString().toLowerCase(), password_.getText().toString());

//                System.out.print(username_);
//                System.out.print(password_);
//                System.out.print(verfied);

                if (verfied.getId() != -1) {
                    promptTo = "Login Success.";

                    System.out.println(verfied.getId());
                    System.out.println(verfied.getName());
                    System.out.println(verfied.getEmail());
                    System.out.println(verfied.getPassword());
                    System.out.println(verfied.getYearsOfExperience());
                    System.out.println(verfied.getDepartment());

                    TextView auth = findViewById(R.id.auth);
                    auth.setText(promptTo);

                    Intent i = new Intent(getApplicationContext(), choose_subjects.class);
                    i.putExtra("Name", verfied.getName());
                    i.putExtra("Email", verfied.getEmail());
                    i.putExtra("Password", verfied.getPassword());
                    i.putExtra("Experience", verfied.getYearsOfExperience());
                    i.putExtra("Department", verfied.getDepartment());
                    startActivity(i);
                    setContentView(R.layout.activity_choose_subjects);

                }
                else {
                    promptTo = " ";
                    TextView auth = findViewById(R.id.auth);
                    auth.setText(promptTo);
                }


            }
        });

        Button signUp = findViewById(R.id.signup);

        signUp.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(), SignUp.class);
                startActivity(i);
                setContentView(R.layout.activity_sign_up);

            }
        });

    }
}
