package com.androidcodefinder.FacultyAssigner;

public class User {

    private int id;
    private int yearsOfExperience;
    private String name;
    private String username;
    private String password;
    private String department;

    public User(){

    }

    public User(int id, String name, String username, String password, int yearsOfExperience, String department){
        this.id = id;
        this.name = name;
        this.username = username;
        this.password = password;
        this.yearsOfExperience = yearsOfExperience;
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(int yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return username;
    }

    public void setEmail(String email) {
        this.username = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}