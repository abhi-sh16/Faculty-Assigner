package com.androidcodefinder.loginapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.androidcodefinder.FacultyAssigner.DatabaseHelper;
import com.androidcodefinder.FacultyAssigner.MainActivity;
import com.androidcodefinder.FacultyAssigner.R;
import com.androidcodefinder.FacultyAssigner.User;

public class SignUp extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        final DatabaseHelper dbh = new DatabaseHelper(this);

        final Spinner dropdown = findViewById(R.id.department);
        String[] items = new String[]{"CSE", "ECE", "CCE", "ME", "MME", "PHYSICS", "MATHEMATICS", "HSS"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        Button logIn = findViewById(R.id.login);

        logIn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                setContentView(R.layout.activity_main);

            }
        });

        Button signUp = findViewById(R.id.signup);


        signUp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText username_ = findViewById(R.id.username);
                EditText password_ = findViewById(R.id.password);
                EditText yearsofEx = findViewById(R.id.experience);
                EditText name_ = findViewById(R.id.name);

                TextView auth = findViewById(R.id.auth);

                String promptTo;

                try {
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(password_.getWindowToken(), 0);

                } catch (Exception e) {
                    // TODO: handle exception
                }

                int yearsOfExperience = Integer.parseInt(yearsofEx.getText().toString());
                String name = name_.getText().toString();
                String username = username_.getText().toString();
                String password = password_.getText().toString();
                String department = dropdown.getSelectedItem().toString();

//                System.out.print(department);

                if(username.equals("") || password.equals("")) {
                    promptTo = "Failed To Register, Enter valid username or Password.";

                } else {
                    User akshay = new User(1, name, username, password, yearsOfExperience, department);
                    dbh.addUser(akshay);
                    dbh.getAllUser();
                    promptTo = "Successfully Registered Please login.";
                }


                auth.setText(promptTo);


            }
        });
    }
}
