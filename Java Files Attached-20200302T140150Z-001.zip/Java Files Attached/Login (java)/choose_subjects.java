package com.androidcodefinder.loginapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.androidcodefinder.FacultyAssigner.DatabaseHelper;
import com.androidcodefinder.FacultyAssigner.MainActivity;
import com.androidcodefinder.FacultyAssigner.R;
import com.androidcodefinder.FacultyAssigner.User;
import com.androidcodefinder.FacultyAssigner.UserChoiceDbHelper;
import com.androidcodefinder.FacultyAssigner.UserChoices;

import java.util.Calendar;

public class choose_subjects extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_subjects);

        final String Name = getIntent().getStringExtra("Name");
        final String Email = getIntent().getStringExtra("Email");
        final String Password = getIntent().getStringExtra("Password");
        final int Experience = getIntent().getIntExtra("Experience", '1');
        final String Department = getIntent().getStringExtra("Department");

        TextView userInfo = findViewById(R.id.aboutUser);
        TextView choose4sub = findViewById(R.id.doesnotMatter);

        final UserChoiceDbHelper dbh = new UserChoiceDbHelper(this);

        final Spinner dropdown = findViewById(R.id.sub1);
        final Spinner dropdown1 = findViewById(R.id.sub2);
        final Spinner dropdown2 = findViewById(R.id.sub3);
        final Spinner dropdown3 = findViewById(R.id.sub4);

        Button submit = findViewById(R.id.submit);
        Button back=findViewById(R.id.button5);

        userInfo.setText("Hello " + Name);

        if(dbh.checkUser(Email)){
            TextView auth = findViewById(R.id.auth);
            auth.setText("You've Already Submitted, you won't be able to change now.");
            dropdown.setVisibility(View.INVISIBLE);
            dropdown1.setVisibility(View.INVISIBLE);
            dropdown2.setVisibility(View.INVISIBLE);
            dropdown3.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.INVISIBLE);
            choose4sub.setVisibility(View.INVISIBLE);

        }


        if (Calendar.getInstance().get(Calendar.MONTH) + 1 < 4) {
            //            Even Sem
            if (Department.equals("CSE") || Department.equals("CCE")) {
                String[] items = new String[]{"-", "DSA", "DSA lab", "DMS", "DAA", "OS", "TOC", "CN", "Compiler Design",
                        "Compiler Design(CD)-Lab", "Image Processing", "Computer Graphics CG", "Introduction to Bioinformatics" +
                        "", "Computer Security", "Cryptographic Algorithms", "Computer Vision",
                        "Software Metrics and Design Strategies", "Introduction to Enterprise Architectures", "Social Network Analysis"};
                ShowDropdown(items);
            } else if (Department.equals("ECE")) {
                String[] items = new String[]{"-", "DSY", "ANEL", "ANEL Lab", "NAS", "POC", "" +
                        "SSC-Lab", "CSE", "MWE", "MWE-Lab", "IVLSI", "Microwave and Optical Communication Lab (MOC Lab) ",
                        "Microwave Engineering (MWE) (In lieu of PES) ", "Computer Networks (CN) ", "Computer Networks Lab (CN-L)",
                        "Antenna Engineering", "Embedded Systems", "Digital Systems Design with FPGAs", "Telecommunications Switching Systems and",
                        "Networks", "Advanced DSP", "Internet of Things", "Wireless Communication", "Broadband Communication",
                        "Embedded Systems and Design",
                        "Modeling and Simulation", "System Level Specifications and Design", "Modeling and Simulation",
                        "Wireless Communication", "Embedded Systems and Design", "Digital System Design with FPGAs", "VLSI Lab", "PG Laboratory - 2"};
                ShowDropdown(items);
            } else if (Department.equals("ME") || Department.equals("MME")) {
                String[] items = new String[]{"-", "EG Lab", "EPM", "Machine Design 1 (MD1) ",
                        "Kinematics & Dynamics (K&D) ", "Kinematics & Dynamics Lab (K&D Lab) ",
                        "Fluid Mechanics & Machinery (FMM) ", "Fluid Mechanics & Machinery Lab (FMM Lab) ",
                        "Metrology, Instrumentation and Control (METIC) ", "Metrology, Instrumentation and Control Lab (METIC Lab) ",
                        "Total Quality Management (TQM)", "Manufacturing Technology 2 (MT2)", "IC Engines (ICE) ",
                        "IC Engines Lab (ICE Lab) ", "CAD – CAM ", "CAD – CAM Lab ", "Finite Element Methods (FEM) ",
                        "Finite Element Methods Lab (FEM Lab)", "Robotics and Industrial Automation (ROBO) ",
                        "Robotics and Industrial Automation Lab (ROBO Lab)", "CAD – CAM ", "CAD – CAM ", "Finite Element Methods (FEM)"};
                ShowDropdown(items);
            } else if (Department.equals("HSS")) {
                String[] items = new String[]{"-", "EEB", "VEE", "PTS", "EFE"};
                ShowDropdown(items);
            } else if (Department.equals("PHYSICS")) {
                String[] items = new String[]{"-", "Physics", "P-2", "P-2 Lab"};
                ShowDropdown(items);
            } else if (Department.equals("MATHEMATICS")) {
                String[] items = new String[]{"-", "M-2", "P&S"};
                ShowDropdown(items);
            }
        } else {
            //            Odd Sem
            if (Department.equals("CSE") || Department.equals("CCE")) {
                String[] items = new String[]{"-", "CP", "CP lab", "IS & M", "IR", "IMAD", "IDS", "UMC",
                        "GAA", "MPA", "CS", "SWE", "AI", "COA", "AP", "IDBMS",
                        "OTA", "DM", "FNFT", "CC", "RTS", "CPSDS", "DL", "ISD LAB"};
                ShowDropdown(items);
            } else if (Department.equals("ECE")) {
                String[] items = new String[]{"-", "B.E.", "B.E  lab", "MICROI", "IGCN", "EMPC", "DSP", "DC",
                        "SEMI", "EEM", "S&S", "DCS", "ITC", "MDC", "DFT", "IIP", "RFE", "AVLSIC"};
                ShowDropdown(items);
            } else if (Department.equals("ME") || Department.equals("MME")) {
                String[] items = new String[]{"-", "HT", "MID-2", "CAD-CAM", "MSI", "ICHEM",
                        "UMP", "ET", "IEM", "MT 1", "MOS", "MEET", "PPE", "WMWP", "ATE", "CFD", "MVIB", "AMOS"};
                ShowDropdown(items);
            } else if (Department.equals("MATHEMATICS")) {
                String[] items = new String[]{"-", "M-I", "M-III"};
                ShowDropdown(items);
            } else if (Department.equals("HSS")) {
                String[] items = new String[]{"-", "TCE", "EFE", "PTS"};
                ShowDropdown(items);
            } else if (Department.equals("PHYSICS")) {
                String[] items = new String[]{"-", "CLP"};
                ShowDropdown(items);
            } else if (Department.equals("OTHER ELECTIVE")) {
                String[] items = new String[]{"-", "CTWW", "OPTI", "IVP", "AUTOSAR", "SBA", "EALSA", "MSE", "BFSS", "IST",
                        "TSAI", "QCQ1"};
                ShowDropdown(items);
            }
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                setContentView(R.layout.activity_main);
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String name_ = Name;
                String username_ = Email;
                String password_ = Password;
                int experience_ = Experience;
                String department_ = Department;

                String cho_1 = dropdown.getSelectedItem().toString();
                String cho_2 = dropdown1.getSelectedItem().toString();
                String cho_3 = dropdown2.getSelectedItem().toString();
                String cho_4 = dropdown3.getSelectedItem().toString();

                TextView auth = findViewById(R.id.auth);

                String promptTo;

                if(cho_1.equals("-") || cho_2.equals("-") || cho_3.equals("-") || cho_4.equals("-")) {
                    promptTo = "Select Right Subjects.";
                } else {
                    UserChoices akshay = new UserChoices(1, name_, username_, cho_1, cho_2, cho_3, cho_4, experience_, department_, "True");
                    dbh.addUser(akshay);
                    dbh.getAllUser();
                    promptTo = "Successfully Added In DB.";
                }


                auth.setText(promptTo);

            }
        });


    }

    public void ShowDropdown(String items[]) {
        final Spinner dropdown = findViewById(R.id.sub1);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        final Spinner dropdown1 = findViewById(R.id.sub2);
        dropdown1.setAdapter(adapter);

        final Spinner dropdown2 = findViewById(R.id.sub3);
        dropdown2.setAdapter(adapter);

        final Spinner dropdown3 = findViewById(R.id.sub4);
        dropdown3.setAdapter(adapter);
    }
}
