package com.androidcodefinder.FacultyAssigner;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

import com.androidcodefinder.FacultyAssigner.UserChoiceDbHelper;
import com.androidcodefinder.FacultyAssigner.DatabaseHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class admin extends AppCompatActivity {

    SQLiteDatabase db;
    public static TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);


//        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
//        List<User> users = databaseHelper.getAllUser();
//        Log.d("Debug", String.valueOf(users));
//
     // UserChoiceDbHelper userChoiceDbHelper = new UserChoiceDbHelper(this);
     // List<UserChoices> userChoices = userChoiceDbHelper.getAllUser();
//      Log.d("Debug", String.valueOf(users));

        Button assign = findViewById(R.id.assignButton);
        final  Button back1=findViewById(R.id.button6);
        assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                List<User> user = databaseHelper.getAllUser();
                UserChoiceDbHelper userChoiceDbHelper = new UserChoiceDbHelper(getApplicationContext());
                List<UserChoices> userChoices = userChoiceDbHelper.getAllUser();
                textView = findViewById(R.id.textView);
                textView.setMovementMethod(new ScrollingMovementMethod());
                textView.setText(" ");

                back1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(i);
                        setContentView(R.layout.activity_main);
                    }
                });

//                Iterator<User> i = new Iterator<User>() {
//                    @Override
//                    public boolean hasNext() {
//                        textView.setText(String.valueOf(User));
//                        return false;
//                    }
//
//                    @Override
//                    public User next() {
//                        return null;
//                    }
//                };

               // UserChoiceDbHelper userChoiceDbHelper = new UserChoiceDbHelper(admin.this);
               // List<UserChoices> userChoices = userChoiceDbHelper.getAllUser();
//                Log.d("Debug", String.valueOf(userChoices.get(1)));


                String [][] arr = new String[50][8];
                String[] courses=new String[50];
                int [][] arr1=new int[50][8];
                String[] computerscience = new String[]{"-", "CP", "CP lab", "IS & M", "IR", "IMAD", "IDS", "UMC",
                        "GAA", "MPA", "CS", "SWE", "AI", "COA", "AP", "IDBMS",
                        "OTA", "DM", "FNFT", "CC", "RTS", "CPSDS", "DL", "ISD LAB"};
                int size=user.size();

                int i=0,j=0;
                while(i<size) {


                        arr[i][0]=String.valueOf(user.get(i).getName());
                        arr[i][1]=String.valueOf(user.get(i).getDepartment());
                        arr[i][2]=String.valueOf(userChoices.get(i).getChoice_1());
                        arr[i][3]=String.valueOf(userChoices.get(i).getChoice_2());
                         arr[i][4]=String.valueOf(userChoices.get(i).getChoice_3());
                             arr[i][5]=String.valueOf(userChoices.get(i).getChoice_4());
                    arr[i][6]=String.valueOf(user.get(i).getYearsOfExperience());
                    arr[i][7]="T";




                    i++;
                }

                i=0;
                for(i=0;i<size;i++){
                   arr1[i][0]=Integer.parseInt(arr[i][6]);
                 arr1[i][1]=i;
               }
               int temp1,temp,count,flag;
                   for(i=0;i<size;i++) {
                        temp=arr1[i][0];
                       for(j=i+1;j<size;j++){
                            temp1=arr1[j][0];
                           if(temp<temp1){
                               arr1[i][0]=temp1;
                               count=arr1[i][1];
                               arr1[i][1]=arr1[j][1];
                               arr1[j][0]=temp;
                               arr1[j][1]=count;
                           }
                       }
                   }
                textView.append("Course Selected\n");
                textView.append("\n");
                textView.append("\n");
                for(i=0;i<size;i++) {
                    textView.append(arr[i][0]+"\n"+ " " +"1-"+ arr[i][2]+ " " +"2-"+ arr[i][3]+ " " +"3-"+ arr[i][4]+ " " +"4-"+ arr[i][5]+"\n");
                }
                textView.append("\n");
                textView.append("\n");
                textView.append("\n");
                textView.append("Course Assigned to the faculties\n");
                textView.append("\n");
                textView.append("\n");

                   int k=0,value,courseindex=0;
                   for(i=2;i<6;i++){
                       for(j=0;j<size;j++){
                           flag=0;
                           k=0;
                           value=arr1[j][1];
                          while(k<courseindex){
                                    if(courses[k].equals(arr[value][i])){
                                        flag=1;
                                        break;
                                    }
                                    k++;
                           }
                           if(flag==0 && arr[value][7]=="T" ){
                              courses[courseindex++]=arr[value][i];
                              arr[value][7]="F";
                               textView.append(arr[value][0]+ " ---" + arr[value][i]+ " " + "\n");
                               textView.append("\n");
                           }

                       }


                   }
                textView.append("\n");
                textView.append("\n");
                textView.append("\n");
                textView.append("\n");
                textView.append("\n");
                textView.append("Courses Assigned\n");
                textView.append("\n");
                textView.append("\n");
                for(i=0;i<courseindex;i++) {
                    textView.append(courses[i]+"\n");
                }
            //    textView.append(arr[2][0]+ " ---" + arr[2][5]+ " " + "\n");


            }
        });
    }



}
